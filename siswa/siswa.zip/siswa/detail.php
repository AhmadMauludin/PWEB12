<div class="row">
    <div class="col-md-12">
        <div class="page-header">
            <h4>
                <i class="glyphicon glyphicon-edit"></i>
                Detail data siswa
            </h4>
        </div> <!-- /.page-header -->
        <?php
        if (isset($_GET['id'])) {
            $nis   = $_GET['id'];
            $query = mysqli_query($db, "SELECT * FROM is_siswa WHERE nis='$nis'") or die('Query Error : ' . mysqli_error($db));
            while ($data  = mysqli_fetch_assoc($query)) {
                $nis           = $data['nis'];
                $nama          = $data['nama'];
                $tempat_lahir  = $data['tempat_lahir'];

                $tanggal       = $data['tanggal_lahir'];
                $tgl           = explode('-', $tanggal);
                $tanggal_lahir = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

                $jenis_kelamin = $data['jenis_kelamin'];
                $agama         = $data['agama'];
                $alamat        = $data['alamat'];
                $no_telepon    = $data['no_telepon'];
            }
        }
        ?>

        <ul class="list-group">
            <li class="list-group-item active">DETAIL DATA</li>
            <li class="list-group-item">NIS : <?php echo $nis; ?></li>
            <li class="list-group-item">Nama : <?php echo $nama; ?></li>
            <li class="list-group-item">Lahir : <?php echo $tempat_lahir; ?>, <?php echo $tanggal_lahir; ?></li>
            <li class="list-group-item">Jenis Kelamin : <?php echo $jenis_kelamin; ?></li>
            <li class="list-group-item">Agama : <?php echo $agama; ?></li>
            <li class="list-group-item">Alamat : <?php echo $alamat; ?></li>
            <li class="list-group-item">Telepon : <?php echo $no_telepon; ?></li>
        </ul>

        <div class="form-group">
            <a href="index.php" class="btn btn-default btn-reset">Kembali</a>
        </div>
    </div>
    </form>
</div> <!-- /.panel-body -->
</div> <!-- /.panel -->
</div> <!-- /.col -->
</div> <!-- /.row -->